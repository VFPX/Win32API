﻿using System;
using System.Data;
using System.IO;
using System.ComponentModel;
using System.Windows.Forms;

namespace News2News.Win32.ExampleViewer
{
    public partial class ExampleViewerForm : Form
    {
        string userName = "guest";
        string password = "";

        com.news2news.www.FoxApi foxApi1 = 
            new com.news2news.www.FoxApi();

        DataSet dsExamples = new DataSet();
        DataSet dsExample = new DataSet();

        public ExampleViewerForm()
        {
            InitializeComponent();

            gridExamples.SelectionChanged +=
                new EventHandler(OnExampleSelected);

            tabControl1.Selected +=
                new TabControlEventHandler(DisplaySelectedExample);

            labelExampleLink.Click +=
                new EventHandler(OpenExampleInBrowser);

            PopulateGridOfExamples();
        }

        void OpenExampleInBrowser(object sender, EventArgs e)
        {
            //opens link in default browser
            System.Diagnostics.Process.Start(
                labelExampleLink.Text);
        }

        void DisplaySelectedExample(object sender, TabControlEventArgs e)
        {
            if (tabControl1.SelectedIndex != 1) return;

            textBox1.Enabled = false;
            if (gridExamples.SelectedRows.Count == 0) return;

            textBox1.Text = "Downloading code sample...";

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler(QueryExample);
            worker.RunWorkerCompleted +=
                new RunWorkerCompletedEventHandler(OnExampleQueryComplete);
            worker.RunWorkerAsync();
        }

        void OnExampleQueryComplete(object sender, 
            RunWorkerCompletedEventArgs e)
        {
            string exampleSource =
                dsExample.Tables[0].Rows[0]["body"].ToString();

            //ensures line feeds and carriage returns
            textBox1.Text = exampleSource.Replace(((char)10).ToString(),
                new string(new char[] { (char)13, (char)10 }));

            textBox1.Enabled = true;
        }

        void QueryExample(object sender, DoWorkEventArgs e)
        {
            int exampleId = (int)gridExamples.SelectedRows[0].
                Cells[0].Value;

            string xmlResult = foxApi1.GetExample(exampleId.ToString(),
                userName, password).ToString();

            dsExample.Clear();
            dsExample.ReadXml(new StringReader(xmlResult));
        }

        void OnExampleSelected(object sender, EventArgs e)
        {
            if (gridExamples.SelectedRows.Count == 0) return;
            if (gridExamples.Columns.Count < 3) return;

            int exampleId = (int)gridExamples.SelectedRows[0].
                Cells[0].Value;

            labelExampleLink.Text = gridExamples.SelectedRows[0].
                Cells[2].Value.ToString();
        }

        private void PopulateGridOfExamples()
        {
            dsExamples.Clear();
            labelExampleLink.IsLink = false;
            labelExampleLink.Text = "Loading list of examples...";

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler(QueryListOfExamples);

            worker.RunWorkerCompleted += 
                new RunWorkerCompletedEventHandler(
                OnListOfExamplesQueryComplete);

            worker.RunWorkerAsync();
        }

        void OnListOfExamplesQueryComplete(object sender, 
            RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                labelExampleLink.Text = e.Error.Message;
                return;
            }

            try
            {
                labelExampleLink.IsLink = true;
                labelExampleLink.Text = "";

                ConfigureGridOfExamples();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,
                    ex.GetType().ToString());
            }
        }

        void QueryListOfExamples(object sender, DoWorkEventArgs e)
        {
            dsExamples.ReadXml(new StringReader(
                foxApi1.GetListOfExamples().ToString()));
        }

        private void ConfigureGridOfExamples()
        {
            if (gridExamples.Columns.Count > 0) return;

            gridExamples.AutoGenerateColumns = false;
            gridExamples.Columns.Clear();

            gridExamples.DataSource = dsExamples.Tables[0];
            DataGridViewCell baseCell = new DataGridViewTextBoxCell();

            DataGridViewColumn colId = new DataGridViewColumn(baseCell);
            colId.DataPropertyName = "exampleid";
            colId.HeaderText = "ID";
            colId.Width = 60;
            colId.DefaultCellStyle.Alignment = 
                DataGridViewContentAlignment.MiddleCenter;
            gridExamples.Columns.Add(colId);

            DataGridViewColumn colName = new DataGridViewColumn(baseCell);
            colName.DataPropertyName = "examplename";
            colName.HeaderText = "Title";
            colName.Width = 620;
            gridExamples.Columns.Add(colName);

            DataGridViewColumn colLink = new DataGridViewColumn(baseCell);
            colLink.DataPropertyName = "origlink";
            colLink.Visible = false;
            gridExamples.Columns.Add(colLink);

            OnExampleSelected(this, new EventArgs());
        }
    }
}

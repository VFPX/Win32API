// DirectoryWatch.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"  //define the _WIN32_WINNT macro as 0x0400 or later
#include "conio.h"

void WatchDirectory(LPTSTR Directory);

void _tmain()
{
	for (;;) WatchDirectory("c:\\");
}

void WatchDirectory(LPTSTR Directory)
{
	HANDLE hDirectory;

	hDirectory = CreateFile(Directory,FILE_LIST_DIRECTORY,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, 
		NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);

	if (hDirectory==INVALID_HANDLE_VALUE) return;

	BYTE buffer[0x4000];
	DWORD bytesreturned=0;
	DWORD flags = FILE_NOTIFY_CHANGE_FILE_NAME |
		FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_ATTRIBUTES |
		FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE |
		FILE_NOTIFY_CHANGE_LAST_ACCESS | FILE_NOTIFY_CHANGE_CREATION |
		FILE_NOTIFY_CHANGE_SECURITY;

	if (ReadDirectoryChangesW(hDirectory, buffer, sizeof(buffer),
		true, flags, &bytesreturned, NULL, NULL))
	{
		FILE_NOTIFY_INFORMATION *pNotifyInfo;

		for (DWORD offset=0;;)
		{
			pNotifyInfo = (FILE_NOTIFY_INFORMATION *)&buffer[offset];

			printf("\n%u, ", pNotifyInfo->Action);
			wprintf(pNotifyInfo->FileName);

			if (pNotifyInfo->NextEntryOffset==NULL) break;
			offset += pNotifyInfo->NextEntryOffset;
		}
	}

	CloseHandle(hDirectory);
}
